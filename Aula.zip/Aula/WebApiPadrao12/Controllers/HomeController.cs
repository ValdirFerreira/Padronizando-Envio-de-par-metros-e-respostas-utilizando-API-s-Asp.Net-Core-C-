﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApiPadrao12.Models;

namespace WebApiPadrao12.Controllers
{
    public class HomeController : Controller
    {

        public static List<Produto> ListaProduto = new List<Produto>();


        [HttpPost("/api/SalvarProduto")]
        public JsonResult SalvarProduto([FromBody] ParametrosAPI parametro)
        {
            var retorno = new RetornoAPI();


            if (parametro.codigo == 0)
            {
                retorno.codigo = 1;
                retorno.mensagem = "O código do produto e obrigatório";
            }
            else
            if (string.IsNullOrWhiteSpace(parametro.nome))
            {
                retorno.codigo = 2;
                retorno.mensagem = "O nome do produto e obrigatório";
            }
            else
            {
                ListaProduto.Add(new Produto
                {
                    Codigo = parametro.codigo,
                    Nome = parametro.nome
                });

                retorno.codigo = 0;
                retorno.mensagem = "Produto cadastrado com sucesso";
            }


            return Json(retorno);
        }


        [HttpGet("/api/ListarProdutos")]
        public JsonResult ListarProdutos()
        {
            var retorno = new RetornoAPI();

            var produtos = ListaProduto;

            if (produtos.Count > 0)
            {
                retorno.codigo = 0;
                retorno.mensagem = "Lista retornada com sucesso";
            }
            else
            {
                retorno.codigo = 3;
                retorno.mensagem = "Não existe dados a serem retornados";
            }

            return Json(new { retorno = retorno, produtos = produtos });


        }

















        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
