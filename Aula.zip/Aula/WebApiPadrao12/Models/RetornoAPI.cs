﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiPadrao12.Models
{
    public class RetornoAPI
    {
        public int codigo { get; set; }

        public string mensagem { get; set; }
    }
}
